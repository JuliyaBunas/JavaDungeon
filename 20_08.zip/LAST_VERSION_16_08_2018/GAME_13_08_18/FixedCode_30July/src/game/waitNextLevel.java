/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package game;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author ILYA
 */
public class waitNextLevel extends Thread{
    FXMLDocumentController fx;
    boolean ff = true;
    
    public waitNextLevel(FXMLDocumentController fx){
        this.fx = fx;
    }
    
    public void run(){
        while(ff == true){
            if(((fx.px + 80) >= 1810 && (fx.px - 80) < 1756)){
                System.out.println("YEAH BOYYYYYYYYYY");
                fx.heroIsVisible = false;
                fx.nextLvl.setVisible(true);
                ff = false;
                fx.dialogcloud2.setVisible(false);
                fx.dialog.setVisible(false);
                try {
                    sleep(3420);
                } catch (InterruptedException ex) {
                    Logger.getLogger(waitNextLevel.class.getName()).log(Level.SEVERE, null, ex);
                }
                fx.nextLvl.setVisible(false);
                fx.heroIsVisible = true;
                fx.moveHero = true;
                
                try {
                    sleep(80);
                            } catch (InterruptedException ex) {
                    Logger.getLogger(waitNextLevel.class.getName()).log(Level.SEVERE, null, ex);
                }
                fx.dialog.setVisible(true);
                fx.dialogcloud3.setVisible(true);
                
            }System.out.println(fx.px + "       " + fx.py);
            try {
                sleep(80);
            } catch (InterruptedException ex) {
                Logger.getLogger(waitNextLevel.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
}
