
package game;

import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import game.FXMLDocumentController;
import javafx.animation.AnimationTimer;
import javafx.scene.image.Image;

/**
 *
 * @author PC
 */
public class MonsterThread extends Thread {
    Random rnd = new Random();
    FXMLDocumentController fx;
    int x;
    int y;
    int curMonster;
    int MonsterHp;
    int Monster_Damage;
    int Player_Damage;
    int heal;
    boolean g;
    boolean n;
    
    
    public MonsterThread(FXMLDocumentController fx, int i) {
        this.fx = fx;
        curMonster = i;
        setDaemon(true);
        MonsterHp = fx.MonsterHitpoints;
        Monster_Damage = fx.MonsterDamage;
        Player_Damage = fx.playerDamage;
         n = true;
    }

   
    
    public void spawn() {
        Random rnd = new Random();
        x = rnd.nextInt(1920);
        y = rnd.nextInt(700);
        System.out.println("spawn");
        MonsterHp = fx.MonsterHitpoints;
    }

    private void moveMonsterX(int where) {
        double cx = 0;
        if (where > fx.monstr1.getLayoutX()) {
            cx = fx.monstr1.getLayoutX() + 2;
        }
        if (where < fx.monstr1.getLayoutX()) {
            cx = fx.monstr1.getLayoutX() - 2;
        }

        if (cx > 0 && cx < 1920) {
            fx.monstr1.relocate(cx, fx.monstr1.getLayoutY());
        }
    }

    private void moveMonsterY(int where) {
        double cy = 0;
        if (where > fx.monstr1.getLayoutY()) {
            cy = fx.monstr1.getLayoutY() + 2;
        }
        if (where < fx.monstr1.getLayoutY()) {
            cy = fx.monstr1.getLayoutY() - 2;
        }

        if (cy > 0 && cy < 1080) {
            fx.monstr1.relocate(fx.monstr1.getLayoutX(), cy);
        }
    }
    
    private void tryToBite(){
        if(fx.monstr1.getLayoutX() + 145 >= fx.px && fx.monstr1.getLayoutX() - 145 <= fx.px && fx.monstr1.getLayoutY() - 180 <= fx.py && fx.monstr1.getLayoutY() + 180 >= fx.py){
            fx.playerHitpoints -= Monster_Damage;
            
             //System.out.println("damage to player");
                fx.RedMonitor.setVisible(true);
                
                try {
                    sleep(60);
                    } catch (InterruptedException ex) {
                        Logger.getLogger(MonsterThread.class.getName()).log(Level.SEVERE, null, ex);
                    }
                fx.RedMonitor.setVisible(false);
                if(fx.playerHitpoints <= 0){
                    fx.RedMonitor.setVisible(true);
                    fx.gameOver.setVisible(true);
                    
                }
        }   
    }
    
    private void checkDamage(){
        if(fx.attack == true && fx.px + 230 >= fx.monstr1.getLayoutX() && fx.px - 230 <= fx.monstr1.getLayoutX() && fx.py + 280 >= fx.monstr1.getLayoutY() && fx.py - 280 <= fx.monstr1.getLayoutY()){
                fx.attack = false;
                MonsterHp -= Player_Damage;
                //System.out.println("damage to monster");
                fx.MonstrDamaged.setLayoutX(fx.monstr1.getLayoutX());
                fx.MonstrDamaged.setLayoutY(fx.monstr1.getLayoutY());
                fx.monstr1.setVisible(false);
                fx.MonstrDamaged.setVisible(true);
                try {
                    sleep(50);
                    } catch (InterruptedException ex) {
                        Logger.getLogger(MonsterThread.class.getName()).log(Level.SEVERE, null, ex);
                    }
                fx.MonstrDamaged.setVisible(false);
                fx.monstr1.setVisible(true);
                
                if(MonsterHp <= 0){
                    fx.monstr1.setVisible(false);
                    spawn();
                    fx.monstr1.setLayoutX(x);
                    fx.monstr1.setLayoutY(y);
                    fx.monstr1.setVisible(true);
                    System.out.println("died");
                    fx.killedMonsters += 1;
                }
            }
            
        }
            
    
    
    private void moveMonster(int wherex, int wherey) {
        moveMonsterX(wherex);
        moveMonsterY(wherey);
    }

    /*System.out.println(" ");
            System.out.println((x - cx) + " " + (y - cy));
            System.out.println(fx.px + " " + fx.py);
            System.out.println(" ds");*/
    @Override
    public void run() {
        spawn();
        //spawnCoffee();
        fx.monstr1.setLayoutX(x);
        fx.monstr1.setLayoutY(y);
        fx.monstr1.setVisible(true);
        System.out.println("run");
        while (fx.f != true) {
            
            int x = (int) fx.px, y = (int) fx.py;
            checkDamage();
            moveMonster(x, y);
            tryToBite();
            
            if(fx.killedMonsters >= 4){
                fx.check();
            }
            //checkHeal();
            //System.out.println("PLAYER" + fx.px + " " + fx.py + "      COFFEE" + fx.coffee.getLayoutX() + " " + fx.coffee.getLayoutY());
            
            //System.out.println("PLAYER COORDS    " + fx.px + " " + fx.py);
            //System.out.println("MONSTER COORDS   " + fx.monstr1.getLayoutX() + " " + fx.monstr1.getLayoutY());
            try {
                sleep(15);
            } catch (InterruptedException ex) {
                Logger.getLogger(MonsterThread.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        /*while(fx.monstr1.getLayoutX() != fx.px && fx.monstr1.getLayoutY() != fx.py){
                    moveHeroBy((int)fx.px, (int)fx.py);
                    System.out.print(100);
                    sleep(100);
                }*/

    }
}
